#!/bin/bash
for i; do 
	echo $i 
done