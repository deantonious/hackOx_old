#!/bin/bash

echo "Command: ifconfig" 
echo "`ifconfig `"
exit 0
