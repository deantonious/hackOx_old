#!/bin/bash

echo "Command: fdisk -l" 
echo "`fdisk -l`"
exit 0
